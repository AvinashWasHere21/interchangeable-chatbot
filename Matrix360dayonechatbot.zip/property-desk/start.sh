#!/usr/bin/env bash
# Starts the chat backend on http://localhost:8000 (macOS and Linux). Run: bash start.sh
cd "$(dirname "$0")" || exit 1
python3 -m pip install -r requirements.txt
export ADMIN_KEY="${ADMIN_KEY:-$(python3 -c 'import secrets;print(secrets.token_urlsafe(16))')}"
echo
echo "Admin key for reading leads (this session): $ADMIN_KEY"
echo "Open http://localhost:8000 to try the three demo businesses."
echo
python3 -m uvicorn server:app --port 8000
