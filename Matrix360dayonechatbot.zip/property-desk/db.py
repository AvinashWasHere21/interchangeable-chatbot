"""Storage.

LocalStore  : SQLite file next to the app. Always used. It holds live conversation state, so the
              chat keeps working even if the other database is down or slow.
RemoteSync  : copies every lead change and every chat message to the database your friend builds,
              through a small HTTP API (see DB_CONTRACT.md). Changes are queued in an outbox table
              and retried with back-off, so nothing is lost if his API is offline.
RemoteConfig: optionally reads each business's project data (prices, inventory, amenities...) from
              his database and merges it over clients/<id>.json.
"""
import json
import os
import sqlite3
import threading
import time
import urllib.error
import urllib.request
from contextlib import contextmanager

import schema

BASE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.getenv("DB_PATH", os.path.join(BASE, "chat.db"))


def _sqltype(kind):
    return {"text": "TEXT", "int": "INTEGER", "real": "REAL", "bool": "INTEGER", "json": "TEXT"}[kind]


def _enc(name, v):
    k = schema.KINDS[name]
    if k == "json":
        return json.dumps(v, ensure_ascii=False)
    if k == "bool":
        return None if v is None else int(bool(v))
    return v


def _dec(name, v):
    k = schema.KINDS[name]
    if k == "json":
        try:
            return json.loads(v) if v else schema.blank()[name]
        except (TypeError, ValueError):
            return schema.blank()[name]
    if k == "bool":
        return None if v is None else bool(v)
    return v


class LocalStore:
    def __init__(self, path=DB_PATH):
        self.path = path
        self.lock = threading.RLock()
        with self.conn() as c:
            cols = ", ".join(
                f"{n} {_sqltype(schema.KINDS[n])}" + (" PRIMARY KEY" if n == "lead_id" else "") for n in schema.NAMES
            )
            c.execute(f"CREATE TABLE IF NOT EXISTS leads ({cols})")
            have = {r["name"] for r in c.execute("PRAGMA table_info(leads)")}
            for n in schema.NAMES:  # add columns introduced after the file was first created
                if n not in have:
                    c.execute(f"ALTER TABLE leads ADD COLUMN {n} {_sqltype(schema.KINDS[n])}")
            c.execute("CREATE UNIQUE INDEX IF NOT EXISTS leads_session ON leads(session_id)")
            c.execute("CREATE INDEX IF NOT EXISTS leads_client_phone ON leads(client_id, phone_key)")
            c.execute("CREATE TABLE IF NOT EXISTS lead_messages (id INTEGER PRIMARY KEY AUTOINCREMENT, lead_id TEXT NOT NULL, role TEXT NOT NULL, text TEXT NOT NULL, ts TEXT NOT NULL)")
            c.execute("CREATE INDEX IF NOT EXISTS msg_lead ON lead_messages(lead_id)")
            c.execute("CREATE TABLE IF NOT EXISTS outbox (id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, payload TEXT NOT NULL, attempts INTEGER DEFAULT 0, next_try REAL DEFAULT 0, last_error TEXT DEFAULT '', created REAL)")

    @contextmanager
    def conn(self):
        con = sqlite3.connect(self.path, timeout=15)
        con.row_factory = sqlite3.Row
        try:
            yield con
            con.commit()
        finally:
            con.close()

    # ---- leads
    def _row(self, r):
        if r is None:
            return None
        d = {n: _dec(n, r[n]) for n in schema.NAMES}
        return d

    def by_session(self, session_id):
        with self.conn() as c:
            return self._row(c.execute("SELECT * FROM leads WHERE session_id=?", (session_id,)).fetchone())

    def by_id(self, lead_id):
        with self.conn() as c:
            return self._row(c.execute("SELECT * FROM leads WHERE lead_id=?", (lead_id,)).fetchone())

    def list(self, client_id=None, limit=500):
        q, a = "SELECT * FROM leads", []
        if client_id:
            q += " WHERE client_id=?"
            a.append(client_id)
        q += " ORDER BY updated_at DESC LIMIT ?"
        a.append(limit)
        with self.conn() as c:
            return [self._row(r) for r in c.execute(q, a)]

    def save(self, lead, messages=(), sync=True):
        """Write the lead and any new messages, and queue them for the remote database, in one transaction."""
        with self.lock, self.conn() as c:
            cols = schema.NAMES
            c.execute(
                f"INSERT INTO leads ({', '.join(cols)}) VALUES ({', '.join('?' * len(cols))}) "
                f"ON CONFLICT(lead_id) DO UPDATE SET {', '.join(n + '=excluded.' + n for n in cols if n != 'lead_id')}",
                [_enc(n, lead.get(n)) for n in cols],
            )
            for role, text, ts in messages:
                c.execute("INSERT INTO lead_messages(lead_id,role,text,ts) VALUES(?,?,?,?)", (lead["lead_id"], role, text, ts))
            if sync:
                now = time.time()
                c.execute("INSERT INTO outbox(kind,payload,created) VALUES('lead',?,?)", (json.dumps(crm_record(lead), ensure_ascii=False), now))
                for role, text, ts in messages:
                    c.execute("INSERT INTO outbox(kind,payload,created) VALUES('message',?,?)",
                              (json.dumps({"lead_id": lead["lead_id"], "client_id": lead["client_id"], "role": role, "text": text, "ts": ts}, ensure_ascii=False), now))

    def messages(self, lead_id):
        with self.conn() as c:
            return [dict(r) for r in c.execute("SELECT role,text,ts FROM lead_messages WHERE lead_id=? ORDER BY id", (lead_id,))]

    def message_count(self, lead_id):
        with self.conn() as c:
            return c.execute("SELECT COUNT(*) FROM lead_messages WHERE lead_id=?", (lead_id,)).fetchone()[0]

    # ---- outbox
    def outbox_due(self, limit=50):
        with self.conn() as c:
            return [dict(r) for r in c.execute("SELECT * FROM outbox WHERE next_try<=? ORDER BY id LIMIT ?", (time.time(), limit))]

    def outbox_done(self, ids):
        with self.conn() as c:
            c.executemany("DELETE FROM outbox WHERE id=?", [(i,) for i in ids])

    def outbox_fail(self, row_id, attempts, err):
        delay = min(3600, 15 * 2 ** min(attempts, 8))
        with self.conn() as c:
            c.execute("UPDATE outbox SET attempts=?, next_try=?, last_error=? WHERE id=?", (attempts + 1, time.time() + delay, err[:200], row_id))

    def outbox_stats(self):
        with self.conn() as c:
            r = c.execute("SELECT COUNT(*) n, COALESCE(MAX(attempts),0) a FROM outbox").fetchone()
            last = c.execute("SELECT last_error FROM outbox WHERE last_error != '' ORDER BY id DESC LIMIT 1").fetchone()
            return {"pending": r["n"], "max_attempts": r["a"], "last_error": last["last_error"] if last else ""}


def crm_record(lead):
    """What the other database receives: the lead without internal session fields."""
    return {k: v for k, v in lead.items() if k not in schema.CRM_EXCLUDE}


# ----------------------------------------------------------------------- remote DB
class RemoteSync:
    """Pushes queued lead and message rows to your friend's database.

    DB_FLAVOR=generic   (default) his own REST API:
        POST {DB_API_URL}/leads/upsert     body = lead record      (insert or update by lead_id)
        POST {DB_API_URL}/messages         body = {lead_id, client_id, role, text, ts}
    DB_FLAVOR=postgrest  Supabase / PostgREST tables named `leads` and `lead_messages`:
        POST {DB_API_URL}/leads?on_conflict=lead_id        (merge-duplicates)
        POST {DB_API_URL}/lead_messages
    Auth: DB_API_KEY is sent as `Authorization: Bearer <key>` (and `apikey: <key>` for postgrest).
    """

    def __init__(self):
        self.url = os.getenv("DB_API_URL", "").rstrip("/")
        self.key = os.getenv("DB_API_KEY", "")
        self.flavor = os.getenv("DB_FLAVOR", "generic").lower()

    @property
    def enabled(self):
        return bool(self.url)

    def _headers(self, extra=None):
        h = {"Content-Type": "application/json", "Accept": "application/json"}
        if self.key:
            h["Authorization"] = f"Bearer {self.key}"
            if self.flavor == "postgrest":
                h["apikey"] = self.key
        h.update(extra or {})
        return h

    def _req(self, method, path, body=None, extra=None):
        data = json.dumps(body, ensure_ascii=False).encode() if body is not None else None
        req = urllib.request.Request(self.url + path, data=data, method=method, headers=self._headers(extra))
        with urllib.request.urlopen(req, timeout=8) as r:
            raw = r.read()
            return json.loads(raw) if raw else None

    def send(self, kind, payload):
        if self.flavor == "postgrest":
            if kind == "lead":
                self._req("POST", "/leads?on_conflict=lead_id", payload, {"Prefer": "resolution=merge-duplicates,return=minimal"})
            else:
                payload = {k: v for k, v in payload.items() if k != "client_id"}
                self._req("POST", "/lead_messages", payload, {"Prefer": "return=minimal"})
        else:
            self._req("POST", "/leads/upsert" if kind == "lead" else "/messages", payload)

    def flush(self, store, limit=50):
        """Send due outbox rows in order. Stops at the first failure for a given lead so order is kept."""
        if not self.enabled:
            return 0
        sent, blocked = [], set()
        for row in store.outbox_due(limit):
            payload = json.loads(row["payload"])
            lid = payload.get("lead_id")
            if lid in blocked:
                continue
            try:
                self.send(row["kind"], payload)
                sent.append(row["id"])
            except Exception as e:  # noqa: BLE001  (network, HTTP error, bad JSON)
                blocked.add(lid)
                store.outbox_fail(row["id"], row["attempts"], f"{type(e).__name__}: {e}")
        if sent:
            store.outbox_done(sent)
        return len(sent)


class RemoteConfig:
    """Optional: read a business's project data from the database and merge it over the JSON file.

    GET {DB_API_URL}/clients/{client_id}  -> JSON object with any of the config keys (see clients/*.json).
    For postgrest: GET /clients?id=eq.{client_id}&select=config -> [{"config": {...}}]
    Cached for CONFIG_TTL seconds. If the call fails the JSON file alone is used.
    """

    def __init__(self, remote):
        self.remote = remote
        self.ttl = int(os.getenv("CONFIG_TTL", "60"))
        self.cache = {}
        self.enabled = remote.enabled and os.getenv("CONFIG_FROM_DB", "0") == "1"

    def get(self, client_id):
        if not self.enabled:
            return None
        hit = self.cache.get(client_id)
        if hit and time.time() - hit[0] < self.ttl:
            return hit[1]
        data = None
        try:
            if self.remote.flavor == "postgrest":
                rows = self.remote._req("GET", f"/clients?id=eq.{client_id}&select=config")
                data = rows[0]["config"] if rows else None
            else:
                data = self.remote._req("GET", f"/clients/{client_id}")
        except Exception as e:  # noqa: BLE001
            print("remote config unavailable:", type(e).__name__)
        self.cache[client_id] = (time.time(), data)
        return data


def deep_merge(base, over):
    """Dicts merge key by key. Lists and scalars from `over` replace the base value."""
    if not isinstance(over, dict):
        return base
    out = dict(base)
    for k, v in over.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        elif v is not None:
            out[k] = v
    return out
