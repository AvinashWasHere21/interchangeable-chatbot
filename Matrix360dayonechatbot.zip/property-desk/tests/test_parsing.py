import os
import sys
from datetime import date

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pytest

from parsing import (clean_phone, parse_budget, parse_role, parse_size, parse_timeline,
                     parse_when, parse_yes_no, normalize_numbers)


@pytest.mark.parametrize("text,lo,hi", [
    ("about seventy lakhs", 70, 70),
    ("around seventy five lakh", 75, 75),
    ("eighty-five lacs", 85, 85),
    ("70L", 70, 70),
    ("1.2 cr", 120, 120),
    ("1.2cr", 120, 120),
    ("one point two crore", 120, 120),
    ("one and a half crore", 150, 150),
    ("a crore", 100, 100),
    ("half a crore", 50, 50),
    ("dedh crore", 150, 150),
    ("1 crore 20 lakh", 120, 120),
    ("one crore twenty lakhs", 120, 120),
    ("75,00,000", 75, 75),
    ("₹7500000", 75, 75),
    ("sixty to seventy lakhs", 60, 70),
    ("50-70 lakh", 50, 70),
    ("between 50 and 70 lakhs", 50, 70),
    ("50 lakh to 1 crore", 50, 100),
    ("pachas lakh", 50, 50),
    ("2bhk under 80 lakhs", None, 80),
    ("max 90 lac", None, 90),
    ("70 lakh tak", None, 70),
    ("above 1 crore", 100, None),
    ("1 crore plus", 100, None),
    ("our budget is roughly 65 lakhs only", 65, 65),
    ("7 million", 70, 70),
])
def test_budget(text, lo, hi):
    r = parse_budget(text)
    assert r and "min_lakh" in r, (text, r)
    assert r["min_lakh"] == lo and r["max_lakh"] == hi, (text, r)


def test_budget_flags():
    assert parse_budget("about seventy lakhs")["approx"] is True
    assert parse_budget("70 lakh")["approx"] is False
    assert parse_budget("prefer not to say")["unknown"]
    assert parse_budget("EMI of 25 thousand per month") == {"emi": True}
    assert parse_budget("2 bhk please") is None
    assert parse_budget("9876543210") is None  # a phone number is never a budget
    assert parse_budget("70", awaiting=True)["assumed"] == "lakh"
    assert parse_budget("2", awaiting=True) == {"ambiguous": 2.0}


def test_budget_labels():
    assert parse_budget("about seventy lakhs")["label"] == "about ₹70 lakh"
    assert parse_budget("1.2 cr")["label"] == "₹1.2 crore"
    assert parse_budget("under 80 lakh")["label"] == "up to ₹80 lakh"
    assert parse_budget("60 to 70 lakh")["label"] == "₹60 to 70 lakh"


@pytest.mark.parametrize("text,lo,hi,unit", [
    ("2 bhk", 2, 2, "bhk"), ("two bhk", 2, 2, "bhk"), ("2 or 3 bhk", 2, 3, "bhk"),
    ("3BHK", 3, 3, "bhk"), ("2-3 katha", 2, 3, "katha"), ("dedh katha", 1.5, 1.5, "katha"),
    ("4 katha or more", 4, None, "katha"), ("1200 sqft", 1200, 1200, "sq ft"),
    ("about 5,000 sq ft", 5000, 5000, "sq ft"), ("2 acres", 2, 2, "acre"),
    ("up to 3 katha", None, 3, "katha"),
])
def test_size(text, lo, hi, unit):
    r = parse_size(text)
    assert r and (r["min"], r["max"], r["unit"]) == (lo, hi, unit), (text, r)


def test_size_none():
    assert parse_size("hello there") is None
    assert parse_size("under 80 lakhs") is None


@pytest.mark.parametrize("text,val", [
    ("in 3 months", 3), ("within six months", 6), ("next month", 1.5), ("asap", 1.0),
    ("not decided", "undecided"), ("just exploring", "undecided"), ("a couple of months", 2.0),
    ("next year", 12.0), ("2 weeks", pytest.approx(2 / 4.3 if 2 / 4.3 > 0.5 else 0.5)),
])
def test_timeline(text, val):
    assert parse_timeline(text) == val


def test_role():
    assert parse_role("it's for my father") == "helping"
    assert parse_role("just researching") == "researching"
    assert parse_role("I'm the decision maker") == "decision_maker"
    assert parse_role("for myself") == "decision_maker"
    assert parse_role("hello") is None


def test_when():
    today = date(2026, 10, 12)  # Monday
    assert parse_when("tomorrow morning", today)["label"] == "Tue 13 Oct, Morning"
    assert parse_when("saturday 11am", today)["label"] == "Sat 17 Oct, 11 AM"
    assert parse_when("20 oct evening", today)["date"] == date(2026, 10, 20)
    r = parse_when("whenever my uncle is free", today)
    assert r["parsed"] is False and r["label"]


def test_phone_yes_no():
    assert clean_phone("+91 98765-43210") == ("+919876543210", "9876543210")
    assert clean_phone("09876543210")[1] == "9876543210"
    assert clean_phone("12345") is None
    assert clean_phone("5876543210") is None
    assert parse_yes_no("yes please") is True
    assert parse_yes_no("no, only here") is False
    assert parse_yes_no("maybe") is None


def test_normalize():
    assert normalize_numbers("about seventy five lakhs") == "about 75 lakhs"
