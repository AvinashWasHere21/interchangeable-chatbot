@echo off
cd /d "%~dp0"
python -m pip install -r requirements.txt
if "%ADMIN_KEY%"=="" set ADMIN_KEY=change-me-to-a-long-secret
echo Admin key: %ADMIN_KEY%
echo Open http://localhost:8000 to try the three demo businesses.
python -m uvicorn server:app --port 8000
