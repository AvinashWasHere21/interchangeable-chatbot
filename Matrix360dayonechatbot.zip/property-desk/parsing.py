"""Rule-based understanding of messy Indian real-estate answers.

No AI model and no network: only regular expressions and word lists. It handles
things like "about seventy lakhs", "1 cr 20 lakh", "75,00,000", "sixty to seventy lac",
"under a crore", "dedh crore", "2-3 katha", "in a couple of months".

Every parser returns None when it finds nothing, so the caller can ask again instead
of guessing. Money is always returned in lakh rupees (1 crore = 100 lakh).
"""
import re
from datetime import date, datetime, timedelta

# ------------------------------------------------------------------ number words
_SMALL = {
    "zero": 0, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7,
    "eight": 8, "nine": 9, "ten": 10, "eleven": 11, "twelve": 12, "thirteen": 13,
    "fourteen": 14, "fifteen": 15, "sixteen": 16, "seventeen": 17, "eighteen": 18, "nineteen": 19,
    # Hinglish
    "ek": 1, "do": 2, "teen": 3, "char": 4, "chaar": 4, "paanch": 5, "panch": 5, "chhe": 6,
    "chhah": 6, "saat": 7, "aath": 8, "nau": 9, "das": 10, "gyarah": 11, "barah": 12,
    "terah": 13, "chaudah": 14, "pandrah": 15, "solah": 16, "satrah": 17, "atharah": 18,
    "unnis": 19,
}
_TENS = {
    "twenty": 20, "thirty": 30, "forty": 40, "fourty": 40, "fifty": 50, "sixty": 60,
    "seventy": 70, "eighty": 80, "ninety": 90,
    "bees": 20, "tees": 30, "chalis": 40, "pachaas": 50, "pachas": 50, "saath": 60,
    "sattar": 70, "assi": 80, "nabbe": 90, "pachees": 25, "paintees": 35, "paintalis": 45,
    "pachattar": 75, "pachasi": 85, "pachanve": 95,
}
_FRACTION_WORDS = {"dedh": 1.5, "derh": 1.5, "dhai": 2.5, "adhai": 2.5, "sawa": 1.25}
_UNIT_WORDS = (
    r"(?:lakhs?|lacs?|lacks?|lks?|crores?|crs?|cror\w*|karod\w*|million|mn|katha\w*|kattha\w*|cottah|kottah"
    r"|bhk|bigha|acres?|sq|sqft|sft|square|bedrooms?|months?|weeks?|years?|yrs?)"
)


def normalize_numbers(text):
    """Turn spelled-out numbers into digits: 'about seventy five lakhs' -> 'about 75 lakhs'."""
    s = re.sub(r"(?<=[a-z])-(?=[a-z])", " ", text.lower())
    s = re.sub(r"(?<=\d),(?=\d)", "", s)  # 75,00,000 -> 7500000
    toks = re.findall(r"[a-z]+|\d+(?:\.\d+)?|[^\sa-z\d]", s)
    out, i, n = [], 0, len(toks)

    def nxt(j):
        return toks[j] if j < n else ""

    while i < n:
        t = toks[i]
        # "half a crore", "half lakh"
        if t == "half" and re.fullmatch(_UNIT_WORDS, nxt(i + 1)) or (
            t == "half" and nxt(i + 1) in ("a", "an") and re.fullmatch(_UNIT_WORDS, nxt(i + 2))
        ):
            out.append("0.5")
            i += 1
            if nxt(i) in ("a", "an"):
                i += 1
            continue
        if t in _FRACTION_WORDS:
            out.append(str(_FRACTION_WORDS[t]))
            i += 1
            continue
        if t in ("a", "an") and re.fullmatch(_UNIT_WORDS, nxt(i + 1)):
            out.append("1")
            i += 1
            continue
        if t in _SMALL or t in _TENS or t in ("hundred", "sau", "thousand", "hazaar", "hazar"):
            total, cur, j, seen = 0, 0, i, False
            while j < n:
                w = toks[j]
                if w in _SMALL:
                    cur += _SMALL[w]
                elif w in _TENS:
                    cur += _TENS[w]
                elif w in ("hundred", "sau"):
                    cur = max(cur, 1) * 100
                elif w in ("thousand", "hazaar", "hazar"):
                    total += max(cur, 1) * 1000
                    cur = 0
                elif w == "and" and seen and nxt(j + 1) in _SMALL.keys() | _TENS.keys():
                    j += 1
                    continue
                else:
                    break
                seen = True
                j += 1
            val = float(total + cur)
            # "one point five" / "two and a half"
            if nxt(j) == "point" and nxt(j + 1) in _SMALL:
                frac, j = "", j + 1
                while nxt(j) in _SMALL and _SMALL[nxt(j)] < 10:
                    frac += str(_SMALL[nxt(j)])
                    j += 1
                val = float(f"{int(val)}.{frac}")
            elif nxt(j) == "and" and nxt(j + 1) in ("a", "an") and nxt(j + 2) == "half":
                val += 0.5
                j += 3
            elif nxt(j) == "and" and nxt(j + 1) == "half":
                val += 0.5
                j += 2
            elif nxt(j) in ("aur", "ayr") and nxt(j + 1) in ("aadha", "adha"):
                val += 0.5
                j += 2
            out.append(f"{val:g}")
            i = j
            continue
        out.append(t)
        i += 1
    # re-join tokens, keeping decimals and punctuation sensible
    res = ""
    for t in out:
        if res and (re.match(r"[a-z\d]", t) and re.search(r"[a-z\d]$", res)):
            res += " "
        elif res and t in ("(",):
            res += " "
        res += t
    return res


# ------------------------------------------------------------------------ money
_NUM = r"\d+(?:\.\d+)?"
_UL = r"(?:lakhs?|lacs?|lacks?|lks?|lk|l)"
_UC = r"(?:crores?|crs?|cror\w*|karod\w*)"
_UM = r"(?:millions?|mn)"
_MONEY = re.compile(rf"(?P<n>{_NUM})\s*(?P<u>{_UC}|{_UL}|{_UM})(?![a-z])")
_RANGE_PRE = re.compile(rf"(?P<n>{_NUM})\s*(?:-|–|—|to|and|se|tak|or|~)\s*$")
_MAXW = re.compile(
    r"\b(under|below|upto|up to|max|maximum|within|not more than|no more than|less than|at most|"
    r"cap(?:ped)? at|upper limit|budget of up to)\b"
)
_MINW = re.compile(r"\b(above|over|more than|minimum|min|at least|starting|starts?|from|beyond|exceed\w*)\b")
_APPROXW = re.compile(
    r"\b(about|around|approx\w*|roughly|nearly|almost|close to|ballpark|somewhere|in the range|"
    r"approximately|lagbhag|takriban|aas paas)\b|~"
)
_MAX_AFTER = re.compile(r"^\s*(?:\w+\s+){0,2}?(?:or less|or below|or under|and below|tak|max|maximum|se kam|and under)\b")
_MIN_AFTER = re.compile(r"^\s*(?:\w+\s+){0,2}?(?:\+|plus|or more|or above|and above|and more|se zyada|se upar|upar|minimum)")


def _to_lakh(n, unit):
    n = float(n)
    if re.fullmatch(_UC, unit):
        return n * 100
    if re.fullmatch(_UM, unit):
        return n * 10
    return n


def fmt_money(lakh):
    """70 -> '₹70 lakh', 120 -> '₹1.2 crore'."""
    if lakh is None:
        return ""
    if lakh >= 100:
        c = lakh / 100
        return f"₹{c:.2f}".rstrip("0").rstrip(".") + " crore"
    return f"₹{lakh:g} lakh"


def parse_budget(text, awaiting=False):
    """Return a dict or None.

    {min_lakh, max_lakh, approx, label}                       a usable budget
    {"ambiguous": 7.0}                                         bare small number: ask lakh or crore
    {"emi": True}                                              a monthly figure, not a total budget
    {"unknown": True}                                          prefers not to say
    """
    raw = text.lower()
    if re.search(
        r"(prefer not|rather not|don'?t want to (say|share|tell|disclose)|not comfortable|no budget|"
        r"not sure about (the )?budget|skip|budget (is )?(flexible|not fixed|open)|depends|no idea|don'?t know|"
        r"not decided|can'?t say|later|abhi nahi|pata nahi)",
        raw,
    ):
        # "flexible" still counts as not-given for the record
        return {"unknown": True}
    s = normalize_numbers(text)
    ms = list(_MONEY.finditer(s))
    if not ms:
        if re.search(r"\b(emi|per month|monthly|a month|/month|pm)\b", s) and re.search(r"\d", s):
            return {"emi": True}
        # plain rupees written in full: 7500000 or 7000000
        m = re.search(r"(?<![\d.])(\d{6,9})(?![\d.])", s)
        if m and (awaiting or len(m.group(1)) >= 7 or re.search(r"₹|rs|inr|rupee|budget", s)):
            return _build(float(m.group(1)) / 100000, None, s, m.start(), m.end(), None)
        if awaiting:
            m = re.fullmatch(r"\s*(?:rs\.?|inr|₹)?\s*(\d+(?:\.\d+)?)\s*", s)
            if m:
                v = float(m.group(1))
                if v >= 10:
                    r = _build(v, None, s, 0, len(s), None)
                    r["assumed"] = "lakh"
                    return r
                return {"ambiguous": v}
        return None
    # collect (value, start, end) with ranges and crore+lakh compounds
    vals = []
    for m in ms:
        v = _to_lakh(m.group("n"), m.group("u"))
        start = m.start()
        if vals and re.fullmatch(_UL, m.group("u")) and re.fullmatch(r"\s*(?:and\s*)?", s[vals[-1][2]:start]) \
                and vals[-1][3] == "c":
            pv = vals.pop()
            vals.append((pv[0] + v, pv[1], m.end(), "c+l", None))
            continue
        low = None
        pre = _RANGE_PRE.search(s[:start])
        if pre:
            low = _to_lakh(pre.group("n"), m.group("u"))
            start = pre.start()
        kind = "c" if re.fullmatch(_UC, m.group("u")) else "o"
        vals.append((v, start, m.end(), kind, low))
    first = vals[0]
    if len(vals) >= 2 and first[4] is None:
        # "50 lakh to 1 crore", "50 lakh - 70 lakh"
        gap = s[first[2]:vals[1][1]]
        if re.fullmatch(r"\s*(?:-|–|—|to|and|se|or|~|tak)\s*", gap):
            lo, hi = sorted([first[0], vals[1][0]])
            return _build(lo, hi, s, first[1], vals[1][2], None)
    if first[4] is not None:
        lo, hi = sorted([first[4], first[0]])
        return _build(lo, hi, s, first[1], first[2], None)
    return _build(first[0], None, s, first[1], first[2], None)


def _build(v, hi, s, start, end, _):
    if hi is not None:  # explicit range
        lo = v
        approx = bool(_APPROXW.search(s))
        label = f"{'about ' if approx else ''}{_range_label(lo, hi)}"
        return {"min_lakh": lo, "max_lakh": hi, "approx": approx, "label": label}
    before = s[max(0, start - 28):start]
    after = s[end:end + 28]
    if _MAXW.search(before) or _MAX_AFTER.search(after):
        return {"min_lakh": None, "max_lakh": v, "approx": False, "label": f"up to {fmt_money(v)}"}
    if _MINW.search(before) or _MIN_AFTER.search(after):
        return {"min_lakh": v, "max_lakh": None, "approx": False, "label": f"{fmt_money(v)} or more"}
    approx = bool(_APPROXW.search(before) or _APPROXW.search(after))
    return {
        "min_lakh": v, "max_lakh": v, "approx": approx,
        "label": f"{'about ' if approx else ''}{fmt_money(v)}",
    }


def _range_label(lo, hi):
    if lo < 100 <= hi or (lo >= 100) != (hi >= 100):
        return f"{fmt_money(lo)} to {fmt_money(hi)}"
    if hi >= 100:
        return f"₹{lo / 100:g} to {fmt_money(hi)[1:]}"
    return f"₹{lo:g} to {hi:g} lakh"


# ------------------------------------------------------------------------- size
_AREA_UNITS = [
    ("bhk", r"(?:bhk|bedrooms?|bed rooms?|br)"),
    ("katha", r"(?:kathas?|katthas?|kattas?|kathaa)"),
    ("cottah", r"(?:cottahs?|kottahs?|kothas?)"),
    ("sq ft", r"(?:sq\.?\s*(?:ft|feet|foot)|sqft|sft|square\s*(?:feet|foot|ft)|sq\.?\s?f)"),
    ("sq m", r"(?:sq\.?\s*m(?:eter|etre)?s?|sqm|square\s*met(?:er|re)s?)"),
    ("acre", r"(?:acres?)"),
    ("bigha", r"(?:bighas?)"),
    ("sq yd", r"(?:sq\.?\s*(?:yd|yard)s?|gaj)"),
]


def parse_size(text):
    """Return {min, max, unit, label} or None. Understands '2 bhk', '1.5 katha', '2-3 katha', '1200 sqft', '4 katha or more'."""
    s = normalize_numbers(text)
    for unit, pat in _AREA_UNITS:
        # range first: "2 - 3 katha" / "2 to 3 bhk" / "2 or 3 bhk" / "2/3 bhk"
        m = re.search(rf"(?P<a>{_NUM})\s*(?:-|–|to|or|/|and)\s*(?P<b>{_NUM})\s*{pat}(?![a-z])", s)
        if m:
            a, b = sorted([float(m.group("a")), float(m.group("b"))])
            return {"min": a, "max": b, "unit": unit, "label": f"{a:g}–{b:g} {unit}"}
        m = re.search(rf"(?P<a>{_NUM})\s*(?P<plus>\+)?\s*{pat}(?![a-z])", s)
        if m:
            v = float(m.group("a"))
            before = s[max(0, m.start() - 20):m.start()]
            after = s[m.end():m.end() + 20]
            if m.group("plus") or re.search(r"^\s*(or more|and above|or above|plus|\+|and more)", after) \
                    or re.search(r"\b(above|over|more than|at least|minimum|min)\s*$", before):
                return {"min": v, "max": None, "unit": unit, "label": f"{v:g}+ {unit}"}
            if re.search(r"\b(under|below|upto|up to|max|maximum|less than|within)\s*$", before) \
                    or re.search(r"^\s*(or less|or below|and below)", after):
                return {"min": None, "max": v, "unit": unit, "label": f"up to {v:g} {unit}"}
            return {"min": v, "max": v, "unit": unit, "label": f"{v:g} {unit}"}
    return None


# ---------------------------------------------------------------------- timeline
def parse_timeline(text):
    """Return months as a float (1 = within a month), 'undecided', or None."""
    raw = text.lower()
    if re.search(r"(not decided|undecided|no idea|not sure|don'?t know|just (exploring|looking|browsing|checking)|"
                 r"no hurry|not in a hurry|someday|some day|whenever|abhi nahi|pata nahi|not yet decided)", raw):
        return "undecided"
    s = normalize_numbers(text)
    if re.search(r"\b(today|tomorrow|this week|immediately|asap|right away|right now|urgent\w*|this month|"
                 r"ready to (book|buy)|within a week|in a week|next few days|aaj|kal)\b", s):
        return 1.0
    if re.search(r"\bnext month\b", s):
        return 1.5
    m = re.search(rf"(?:in|within|after|around|about|by)?\s*(?P<a>{_NUM})\s*(?:-|to|or)?\s*(?:(?P<b>{_NUM}))?\s*"
                  r"(?P<u>weeks?|months?|mos?|years?|yrs?)", s)
    if m:
        a = float(m.group("a"))
        b = float(m.group("b")) if m.group("b") else a
        v = max(a, b)
        u = m.group("u")
        if u.startswith("w"):
            return max(0.5, v / 4.3)
        if u.startswith("y"):
            return v * 12
        return v
    if re.search(r"\b(couple of|couple) months?\b", s):
        return 2.0
    if re.search(r"\b(few|some) months?\b", s):
        return 3.0
    if re.search(r"\bnext (quarter)\b", s):
        return 3.0
    if re.search(r"\b(next year|a year|one year|this year end|year end|after a year)\b", s):
        return 12.0
    if re.search(r"\bhalf a year|half year|six months\b", s):
        return 6.0
    return None


# ------------------------------------------------------------------------- role
def parse_role(text):
    s = text.lower()
    if re.search(r"(just|only)?\s*(research\w*|exploring|looking around|browsing|comparing|gathering info|checking out|window shopping)", s) \
            and not re.search(r"\b(i('| a)?m|i am) (the )?(buyer|decision)", s):
        return "researching"
    if re.search(r"(for my (father|mother|dad|mom|parents|brother|sister|son|daughter|friend|boss|client|company|relative|uncle|aunt|in-?laws?)|"
                 r"on behalf|helping|someone else|for a client|for my (family member|cousin)|agent|broker|consultant)", s):
        return "helping"
    if re.search(r"(decision[- ]?maker|i (will|am going to|'ll) (decide|buy|book)|i('| a)?m (the )?(buyer|owner|deciding)|"
                 r"for myself|for me\b|myself|my own|i decide|my decision|i('m| am) buying|me and my (wife|husband|spouse|partner))", s):
        return "decision_maker"
    return None


# ----------------------------------------------------------------- visit / date
_WEEKDAYS = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
_MONTHS = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"]


def parse_when(text, today):
    """Return {'date': date|None, 'time': str|None, 'label': str} or None. Accepts free text as a fallback preference."""
    raw = text.strip()
    if not raw:
        return None
    s = normalize_numbers(raw)
    d = None
    if re.search(r"\btoday\b|\baaj\b", s):
        d = today
    elif re.search(r"\btomorrow\b|\bkal\b", s):
        d = today + timedelta(days=1)
    else:
        for i, w in enumerate(_WEEKDAYS):
            if re.search(rf"\b{w[:3]}(?:{w[3:]})?\b", s) and not re.search(r"\bsat(isf|ur)?\w*\b(?<!\bsat\b)(?<!\bsaturday\b)", s):
                delta = (i - today.weekday()) % 7 or 7
                d = today + timedelta(days=delta)
                break
        if d is None:
            m = re.search(rf"\b(\d{{1,2}})(?:st|nd|rd|th)?\s*(?:of\s*)?({'|'.join(_MONTHS)})[a-z]*", s)
            m2 = re.search(rf"\b({'|'.join(_MONTHS)})[a-z]*\s*(\d{{1,2}})(?:st|nd|rd|th)?\b", s)
            m3 = re.search(r"\b(\d{1,2})[/-](\d{1,2})(?:[/-](\d{2,4}))?\b", s)
            try:
                if m:
                    d = date(today.year, _MONTHS.index(m.group(2)) + 1, int(m.group(1)))
                elif m2:
                    d = date(today.year, _MONTHS.index(m2.group(1)) + 1, int(m2.group(2)))
                elif m3:
                    d = date(today.year, int(m3.group(2)), int(m3.group(1)))
                if d and d < today:
                    d = d.replace(year=d.year + 1)
            except ValueError:
                d = None
        if d is None and re.search(r"\bweekend\b", s):
            d = today + timedelta(days=(5 - today.weekday()) % 7 or 7)
        if d is None and re.search(r"\bnext week\b", s):
            d = today + timedelta(days=7 - today.weekday())
    t = None
    mt = re.search(r"\b(\d{1,2})(?::(\d{2}))?\s*(am|pm)\b", s)
    if mt:
        t = f"{int(mt.group(1))}{':' + mt.group(2) if mt.group(2) else ''} {mt.group(3).upper()}"
    elif re.search(r"\bmorning\b", s):
        t = "Morning"
    elif re.search(r"\bafternoon\b", s):
        t = "Afternoon"
    elif re.search(r"\bevening\b", s):
        t = "Evening"
    elif re.search(r"\bnoon\b", s):
        t = "Noon"
    if d is None and t is None:
        return {"date": None, "time": None, "label": raw[:80], "parsed": False}
    label = d.strftime("%a %d %b") if d else ""
    if re.search(r"\bnext week\b", s) and d:
        label = f"Next week (from {label})"
    if t:
        label = f"{label}, {t}" if label else t
    return {"date": d, "time": t, "label": label.strip(", "), "parsed": True}


# --------------------------------------------------------------------- yes / no
def parse_yes_no(text):
    s = text.lower().strip()
    if re.search(r"\b(no|nope|nah|not now|don'?t|do not|never|nahi|na|only (here|in (this )?chat)|please don'?t)\b", s):
        return False
    if re.search(r"\b(yes|yeah|yep|yup|sure|ok|okay|please|go ahead|fine|haan|ha|ji|of course|absolutely|definitely|agree)\b", s):
        return True
    return None


# ----------------------------------------------------------------- phone / email
def clean_phone(raw):
    """Return (e164, key) for an Indian mobile, or None. Accepts +91, 91, 0 prefixes, spaces and dashes."""
    d = re.sub(r"\D", "", raw or "")
    if len(d) == 12 and d.startswith("91"):
        d = d[2:]
    elif len(d) == 11 and d.startswith("0"):
        d = d[1:]
    if re.fullmatch(r"[6-9]\d{9}", d):
        return f"+91{d}", d
    return None


def parse_email(text):
    m = re.search(r"[\w.+-]+@[\w-]+(?:\.[\w-]+)+", text)
    return m.group(0).lower() if m else None
