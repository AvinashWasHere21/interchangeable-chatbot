# Database contract (for the person building the database)

The chatbot does not care how your database is built. It needs three small things, and you can start with just the first.

Until the database exists nothing breaks: every lead is saved in the chatbot's own `chat.db` and sent to your API as soon as it is reachable (retried automatically with back-off, in order).

## 1. Receive leads and chat messages (required)

Set `DB_API_URL` and `DB_API_KEY`. The chatbot sends `Authorization: Bearer <DB_API_KEY>`.

| Call | Body | Meaning |
|---|---|---|
| `POST {DB_API_URL}/leads/upsert` | one lead record (below) | Insert or update **by `lead_id`**. Sent after every chat turn, so the same row keeps getting fuller. Any 2xx = accepted. |
| `POST {DB_API_URL}/messages` | `{lead_id, client_id, role, text, ts}` | One chat line. `role` is `lead` or `bot`. |

Using Supabase / PostgREST instead? Create the tables from `schema.sql`, set `DB_FLAVOR=postgrest` and `DB_API_URL=https://xxxx.supabase.co/rest/v1`, and no API code is needed.

Calls can arrive twice (retries), so make the upsert idempotent on `lead_id`.

### The lead record

Run `python schema.py` for a Postgres `CREATE TABLE` (also saved as `schema.sql`), or `python schema.py --json` for the field list. One flat row per conversation.

| Field | Script question | Notes |
|---|---|---|
| `lead_id`, `client_id` | which business | `client_id`: `shree-heights`, `lakhotia-industrial`, `vrindavan-greens` |
| `name`, `phone`, `phone_key`, `email` | contact details | `phone` is `+91XXXXXXXXXX`. `phone_key` is the last 10 digits: **use it to spot the same person across chats or businesses** |
| `property_type` | Q1 | `flat` / `industrial` / `plot` |
| `purpose` | Q2 | text label |
| `size_label`, `size_min`, `size_max`, `size_unit` | Q3 | unit: `bhk`, `katha`, `sq ft`, `acre`... |
| `location_pref` | Q4 | text |
| `budget_label`, `budget_min_lakh`, `budget_max_lakh`, `budget_approx` | Q5 | **Always in lakh rupees** (1 crore = 100). "up to 80 lakh" = min null, max 80. "about 70 lakh" = 70/70, approx true |
| `timeline`, `timeline_label` | Q6 | `asap`, `1_3`, `3_6`, `6_plus` (months) |
| `role` | Q7 | `decision_maker`, `helping`, `researching` |
| `features` (JSON array), `features_other` | Q8 | the must-haves they picked or typed |
| `consult_type`, `visit_pref` | Q9 | `visit`, `call`, `none`. `visit_pref` is a **request** such as "Sat 17 Oct, Morning", not a confirmed booking |
| `contact_channel`, `contact_time`, `followup_consent`, `followup_consent_at` | Q10 | **Only contact them outside the chat when `followup_consent` is true.** NULL = not asked, false = refused |
| `unknown_fields` (JSON array) | all | questions the visitor skipped ("not sure", "prefer not to say"). A skipped answer is not a rejection |
| `open_questions` (JSON array) | all | things they asked that the bot could not answer: **a human must answer these** |
| `handoff_requested`, `handoff_reason` | handoff | true when they asked for a team member |
| `score` (`Hot`/`Warm`/`Cold`), `stage`, `summary` | | `summary` is a ready-to-read briefing for the sales team |
| `source`, `page_url`, `utm_*` | | ad attribution |
| `intake_consent` | | ticked the box on the name/mobile form |

`session_id`, `ctx` and `awaiting` stay inside the chatbot and are never sent.

If his schema differs, the cheapest fix is a thin mapping inside his `/leads/upsert` endpoint. Alternatively, edit `crm_record()` in `db.py`, the single place where the outgoing record is built.

## 2. Give the bot real project facts (optional, recommended)

The bot only states what is in its config. It will never invent prices, availability, legal or location facts. If these live in the database, the bot can read them with no code change:

Set `CONFIG_FROM_DB=1`. Then `GET {DB_API_URL}/clients/{client_id}` should return JSON with any of the keys below. They are merged over `clients/<id>.json` (objects merge, lists replace). Postgrest: table `clients(id text, config jsonb)`, read as `/clients?id=eq.{id}&select=config`. Cached for 60 seconds.

```json
{
  "pricing": {
    "published": true,
    "note": "",
    "inventory": [
      {"label": "2 BHK", "match": ["2 bhk", "2bhk"], "price_text": "₹68 to 82 lakh", "area_text": "1,050 to 1,180 sq ft"}
    ]
  },
  "amenities": [{"id": "gym", "label": "Gym", "aliases": ["gym", "fitness"]}],
  "location": {"summary": "...", "landmarks": [{"name": "Station", "distance": "1.5 km", "keys": ["station"]}]},
  "faq": [{"keys": ["possession"], "answer": "Possession is planned for ..."}],
  "budget_bands": [{"id": "b1", "label": "Under ₹40 lakh", "min_lakh": null, "max_lakh": 40}],
  "contact": {"phone": "...", "email": "..."}
}
```

Whatever is added here, the bot treats as confirmed and will say out loud, so only add verified facts. `clients/shree-heights.json` shows every available key.

## 3. Reading leads back (optional)

`GET /api/admin/leads?client_id=...` and `/api/admin/leads.csv` on the chatbot (header `X-Admin-Key`) return what the chatbot holds. `/api/admin/sync` shows how many rows are still waiting to reach your API.
