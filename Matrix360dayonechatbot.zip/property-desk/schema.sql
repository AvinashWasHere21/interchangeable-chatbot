CREATE TABLE IF NOT EXISTS leads (
  lead_id TEXT PRIMARY KEY,
  client_id TEXT NOT NULL,
  session_id TEXT,
  name TEXT,
  phone TEXT,
  phone_key TEXT,
  email TEXT,
  source TEXT,
  page_url TEXT,
  utm_source TEXT,
  utm_medium TEXT,
  utm_campaign TEXT,
  property_type TEXT,
  purpose TEXT,
  size_label TEXT,
  size_min DOUBLE PRECISION,
  size_max DOUBLE PRECISION,
  size_unit TEXT,
  location_pref TEXT,
  budget_label TEXT,
  budget_min_lakh DOUBLE PRECISION,
  budget_max_lakh DOUBLE PRECISION,
  budget_approx BOOLEAN,
  timeline TEXT,
  timeline_label TEXT,
  role TEXT,
  features JSONB,
  features_other TEXT,
  consult_type TEXT,
  visit_pref TEXT,
  contact_channel TEXT,
  contact_time TEXT,
  followup_consent BOOLEAN,
  followup_consent_at TEXT,
  intake_consent BOOLEAN,
  handoff_requested BOOLEAN,
  handoff_reason TEXT,
  unknown_fields JSONB,
  open_questions JSONB,
  score TEXT,
  stage TEXT,
  summary TEXT,
  awaiting TEXT,
  ctx JSONB,
  created_at TEXT,
  updated_at TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS leads_pk ON leads(lead_id);
CREATE INDEX IF NOT EXISTS leads_client_phone ON leads(client_id, phone_key);

CREATE TABLE IF NOT EXISTS lead_messages (
  id BIGSERIAL PRIMARY KEY,
  lead_id TEXT NOT NULL REFERENCES leads(lead_id),
  role TEXT NOT NULL,   -- lead | bot
  text TEXT NOT NULL,
  ts TEXT NOT NULL
);

