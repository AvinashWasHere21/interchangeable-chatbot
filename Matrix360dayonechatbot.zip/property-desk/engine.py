"""The conversation engine: a rule-based flow that follows the 10-question qualification script.

handle(lead, client, text, chip_id) mutates the lead record and returns a Reply dict:
  {"messages": [str], "chips": [{"id","label"}], "quick": [...], "events": [str], "progress": [done, total]}

Rules the bot follows:
  * One question at a time, in script order, skipping anything already known.
  * Every question has clickable options. Typed answers work too and are parsed leniently.
  * Facts come ONLY from the client's config (clients/*.json or the database). If a fact is not
    configured the bot says a team member needs to confirm it. It never invents inventory,
    prices, legal or registration facts, locations or infrastructure.
"""
import re
from datetime import datetime, timedelta, timezone

import parsing as P

IST = timezone(timedelta(hours=5, minutes=30))

# ----------------------------------------------------------------------- defaults
TIMELINE_OPTIONS = [
    {"id": "asap", "label": "Within a month", "max_months": 1, "aliases": ["within a month", "this month", "immediately"]},
    {"id": "1_3", "label": "1–3 months", "max_months": 3, "aliases": ["1-3 months", "1 to 3 months"]},
    {"id": "3_6", "label": "3–6 months", "max_months": 6, "aliases": ["3-6 months", "3 to 6 months"]},
    {"id": "6_plus", "label": "6+ months", "max_months": 9999, "aliases": ["6+ months", "more than 6 months"]},
]
ROLE_OPTIONS = [
    {"id": "decision_maker", "label": "I'm the decision-maker", "aliases": ["decision maker", "decision-maker", "me", "myself", "i decide"]},
    {"id": "helping", "label": "Helping someone else", "aliases": ["helping", "someone else", "for someone", "on behalf"]},
    {"id": "researching", "label": "Just researching", "aliases": ["researching", "research", "exploring", "browsing"]},
]
CONSULT_OPTIONS = [
    {"id": "visit", "label": "Book a site visit", "aliases": ["site visit", "visit", "see the site", "see it"]},
    {"id": "call", "label": "Sales consultation call", "aliases": ["consultation", "sales call", "call", "talk to sales", "callback"]},
    {"id": "none", "label": "Not right now", "aliases": ["not now", "not right now", "no thanks", "later", "maybe later", "no"]},
]
CHANNEL_OPTIONS = [
    {"id": "call", "label": "Phone call", "aliases": ["call", "phone", "ring"]},
    {"id": "whatsapp", "label": "WhatsApp", "aliases": ["whatsapp", "wa", "whats app"]},
    {"id": "sms", "label": "SMS", "aliases": ["sms", "text message", "text"]},
    {"id": "email", "label": "Email", "aliases": ["email", "e-mail", "mail"]},
    {"id": "none", "label": "Only in this chat", "aliases": ["only here", "this chat", "chat only", "no follow up", "don't contact"]},
]
CONTACT_TIME_OPTIONS = [
    {"id": "morning", "label": "Morning (9–12)", "aliases": ["morning"]},
    {"id": "afternoon", "label": "Afternoon (12–4)", "aliases": ["afternoon"]},
    {"id": "evening", "label": "Evening (4–8)", "aliases": ["evening", "night"]},
    {"id": "anytime", "label": "Any time", "aliases": ["any time", "anytime", "whenever", "any"]},
]
VISIT_TIMES = [
    {"id": "morning", "label": "Morning (10–12)", "aliases": ["morning"]},
    {"id": "afternoon", "label": "Afternoon (12–4)", "aliases": ["afternoon"]},
    {"id": "evening", "label": "Evening (4–7)", "aliases": ["evening"]},
    {"id": "any", "label": "Any time", "aliases": ["any time", "anytime", "whenever"]},
]
TYPE_LABELS = {"flat": "flat", "industrial": "industrial property", "plot": "plot"}
TYPE_OPTIONS = [
    {"id": "flat", "label": "Flat / apartment", "aliases": ["flat", "apartment", "bhk", "home"]},
    {"id": "industrial", "label": "Industrial property", "aliases": ["industrial", "warehouse", "factory", "shed", "godown"]},
    {"id": "plot", "label": "Plot / land", "aliases": ["plot", "land", "katha", "bigha"]},
]
DEFAULT_SIZE_PROMPT = {
    "flat": "What size or configuration do you need? Pick one, or type it (for example 2 BHK, or an area in sq ft).",
    "plot": "What plot size are you considering? You can type it in katha or sq ft.",
    "industrial": "What area do you need? You can type it in sq ft, acres or bigha.",
}

STEP_ORDER = ["property_type", "purpose", "size", "location", "budget", "timeline", "role", "features",
              "consult", "visit_when", "channel", "email", "contact_time", "permission"]
STEP_COLS = {
    "property_type": ["property_type"], "purpose": ["purpose"], "size": ["size_label"],
    "location": ["location_pref"], "budget": ["budget_label"], "timeline": ["timeline"],
    "role": ["role"], "consult": ["consult_type"], "visit_when": ["visit_pref"],
    "channel": ["contact_channel"], "email": ["email"], "contact_time": ["contact_time"],
    "permission": ["followup_consent"],
}
SCRIPT_STEPS = ["property_type", "purpose", "size", "location", "budget", "timeline", "role", "features", "consult", "contact"]
FIELD_LABEL = {
    "property_type": "Property type", "purpose": "Purpose", "size": "Size", "location": "Location",
    "budget": "Budget", "timeline": "Timeline", "role": "Role", "features": "Must-haves",
    "consult": "Next step", "contact": "Contact preference",
}
UNSURE_RE = re.compile(
    r"\b(not sure|unsure|don'?t know|dont know|no idea|undecided|not decided|skip|prefer not|rather not|"
    r"can'?t say|pata nahi|nothing specific|no preference|not yet)\b")


def now_iso():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def today_ist():
    return datetime.now(IST).date()


# ----------------------------------------------------------------------- helpers
def _norm(s):
    return re.sub(r"\s+", " ", re.sub(r"[^\w\s+₹]", " ", s.lower())).strip()


def match_option(text, options):
    """Best option whose label or alias appears in the text (longest match wins)."""
    t = " " + _norm(text) + " "
    best, best_len = None, 0
    for o in options:
        cands = [o["label"]] + list(o.get("aliases", []))
        for a in cands:
            a = _norm(a)
            if a and f" {a} " in t and len(a) > best_len:
                best, best_len = o, len(a)
    return best


def opts(c, key, default=None):
    return c.get(key) or default or []


def purposes(lead, c):
    return c.get("purposes", {}).get(lead.get("property_type") or c["property_types"][0], [])


def size_cfg(lead, c):
    return c.get("sizes", {}).get(lead.get("property_type") or c["property_types"][0], {})


def timeline_options(c):
    return c.get("timeline_options") or TIMELINE_OPTIONS


def first_name(lead):
    return (lead.get("name") or "").split(" ")[0] or "there"


def is_answered(lead, step):
    if step in lead["unknown_fields"]:
        return True
    if step == "features":
        return bool(lead["ctx"].get("features_done"))
    return any(lead.get(col) is not None for col in STEP_COLS[step])


def mark_unknown(lead, step):
    if step not in lead["unknown_fields"]:
        lead["unknown_fields"].append(step)


def clear_step(lead, step):
    for col in STEP_COLS.get(step, []):
        lead[col] = None
    if step == "size":
        lead["size_min"] = lead["size_max"] = lead["size_unit"] = None
    if step == "budget":
        lead["budget_min_lakh"] = lead["budget_max_lakh"] = lead["budget_approx"] = None
    if step == "timeline":
        lead["timeline_label"] = None
    if step == "features":
        lead["features"], lead["features_other"] = [], None
        lead["ctx"]["features_done"] = False
    if step == "purpose":
        pass
    if step in lead["unknown_fields"]:
        lead["unknown_fields"].remove(step)


def next_step(lead, c):
    ctx = lead["ctx"]
    if ctx.get("stopped"):
        return None
    if ctx.get("budget_ambig"):
        return "budget"
    if lead["consult_type"] == "visit" and not is_answered(lead, "visit_when"):
        return "visit_when"
    if lead["property_type"] is None and "property_type" not in lead["unknown_fields"]:
        return "property_type"
    for st in ["purpose", "size", "location", "budget", "timeline", "role", "features", "consult"]:
        if not is_answered(lead, st):
            return st
    if lead["consult_type"] == "visit" and not is_answered(lead, "visit_when"):
        return "visit_when"
    if not is_answered(lead, "channel"):
        return "channel"
    if lead["contact_channel"] == "email" and lead["email"] is None:
        return "email"
    if lead["contact_channel"] not in ("none",) and not is_answered(lead, "contact_time"):
        return "contact_time"
    if lead["contact_channel"] not in ("none",) and lead["followup_consent"] is None:
        return "permission"
    return None


# ------------------------------------------------------------------------- chips
def chip(step, oid, label):
    return {"id": f"{step}:{oid}", "label": label}


def chips_for(step, lead, c):
    ctx = lead["ctx"]
    ch = []
    if ctx.get("budget_ambig") and step == "budget":
        v = ctx["budget_ambig"]
        return [chip("budget_unit", "lakh", f"₹{v:g} lakh"), chip("budget_unit", "crore", f"₹{v:g} crore")]
    if step == "property_type":
        ch = [chip(step, t, TYPE_LABELS[t].capitalize()) for t in c["property_types"]]
    elif step == "purpose":
        ch = [chip(step, o["id"], o["label"]) for o in purposes(lead, c)] + [chip(step, "unsure", "Not sure yet")]
    elif step == "size":
        ch = [chip(step, o["id"], o["label"]) for o in size_cfg(lead, c).get("options", [])] + [chip(step, "unsure", "Not sure yet")]
    elif step == "location":
        ch = [chip(step, o["id"], o["label"]) for o in c["location"].get("options", [])] + [chip(step, "unsure", "Not sure yet")]
    elif step == "budget":
        ch = [chip(step, b["id"], b["label"]) for b in c.get("budget_bands", [])] + [chip(step, "unsure", "Prefer not to say")]
    elif step == "timeline":
        ch = [chip(step, o["id"], o["label"]) for o in timeline_options(c)] + [chip(step, "unsure", "Not decided yet")]
    elif step == "role":
        ch = [chip(step, o["id"], o["label"]) for o in ROLE_OPTIONS]
    elif step == "features":
        pool = c.get("amenities") or c.get("requirement_choices") or []
        have = set(lead["features"])
        ch = [chip(step, o["id"], o["label"]) for o in pool if o["label"] not in have][:10]
        ch += [chip(step, "done", "That's all" if have else "Nothing specific")]
    elif step == "consult":
        ch = [chip(step, o["id"], o["label"]) for o in CONSULT_OPTIONS]
    elif step == "visit_when":
        if ctx.get("visit_date"):
            ch = [chip("visit_time", o["id"], o["label"]) for o in VISIT_TIMES]
        else:
            ch = visit_date_chips(c) + [chip("visit_when", "unsure", "Not sure yet")]
    elif step == "channel":
        ch = [chip(step, o["id"], o["label"]) for o in CHANNEL_OPTIONS]
    elif step == "contact_time":
        ch = [chip(step, o["id"], o["label"]) for o in CONTACT_TIME_OPTIONS]
    elif step == "permission":
        ch = [chip(step, "yes", "Yes, that's fine"), chip(step, "no", "No, only in this chat")]
    return ch


def visit_date_chips(c):
    days = c.get("visit", {}).get("days", list(range(7)))
    out, d, today = [], today_ist(), today_ist()
    for i in range(1, 15):
        x = today + timedelta(days=i)
        if x.weekday() in days:
            lab = x.strftime("%a %d %b")
            if i == 1:
                lab = "Tomorrow, " + lab
            out.append({"id": f"visit_when:d:{x.isoformat()}", "label": lab})
        if len(out) == 4:
            break
    return out


def quick_actions(c):
    q = []
    if c["location"].get("summary"):
        q.append({"id": "q:location", "label": "📍 Location"})
    if c.get("amenities"):
        q.append({"id": "q:amenities", "label": "✨ Amenities"})
    q.append({"id": "q:price", "label": "💰 Pricing"})
    q.append({"id": "q:human", "label": "👤 Talk to a team member"})
    return q


# ----------------------------------------------------------------------- prompts
def prompt(step, lead, c):
    ctx = lead["ctx"]
    ptype = lead["property_type"] or c["property_types"][0]
    if ctx.get("budget_ambig") and step == "budget":
        return f"Just to be sure, did you mean ₹{ctx['budget_ambig']:g} lakh or ₹{ctx['budget_ambig']:g} crore?"
    if step == "property_type":
        return "Are you enquiring about a flat, an industrial property, or a plot?"
    if step == "purpose":
        return {"flat": "What will the property be used for?", "plot": "What do you plan to do with the plot?",
                "industrial": "What will you use the industrial property for?"}[ptype]
    if step == "size":
        return size_cfg(lead, c).get("prompt") or DEFAULT_SIZE_PROMPT[ptype]
    if step == "location":
        if c["location"].get("summary"):
            return "Which location or area do you prefer?"
        return "Which location or area do you prefer? Type it in, or pick an option."
    if step == "budget":
        return ("What budget or investment range are you comfortable sharing? You can pick a range or type a number "
                "such as “about 70 lakhs” or “1.2 cr”. It's fine to skip this.")
    if step == "timeline":
        return "When are you looking to decide or visit?"
    if step == "role":
        return "Are you the decision-maker, or helping someone else with this? (Or just researching, which is fine too.)"
    if step == "features":
        if c.get("amenities"):
            if lead["features"]:
                return "Added. Anything else that is essential for you? Tap another, or choose “That's all”."
            return ("Which features matter most to you? These are the ones listed on the project website. "
                    "Tap everything that is essential, then “That's all”.")
        if lead["features"]:
            return "Noted. Anything else that you need? Or choose “That's all”."
        return ("Which infrastructure or features are essential for you? I'll note them for the team, who will confirm "
                "what the project actually offers. Tap all that apply, or type your own.")
    if step == "consult":
        return "Would you like a sales consultation or a site visit?"
    if step == "visit_when":
        if ctx.get("visit_date"):
            return f"Which time of day suits you on {ctx['visit_date']}?"
        return "Which day would suit you for the visit? Tap one, or type a date and time."
    if step == "channel":
        return "How would you like our team to reach you?"
    if step == "email":
        return "What's your email address?"
    if step == "contact_time":
        return "What's the best time to reach you?"
    if step == "permission":
        ch = {o["id"]: o["label"] for o in CHANNEL_OPTIONS}.get(lead["contact_channel"] or "call", "call").lower()
        when = f" in the {lead['contact_time'].lower()}" if lead["contact_time"] else ""
        where = lead["email"] if lead["contact_channel"] == "email" and lead["email"] else lead["phone"]
        return (f"One last thing. May our team contact you on {where} by {ch}{when}, even after this chat ends? "
                "We only follow up if you say yes.")
    return ""


# ----------------------------------------------------------------- intent detection
INTENTS = [
    ("human", r"(\b(talk|speak|chat|connect|transfer)\b.{0,12}\b(to|with)\b.{0,12}\b(human|person|agent|someone|executive|team|sales|representative|manager|owner|somebody)\b|"
              r"\bhuman\b|call me|call back|callback|ring me|give me a call|contact me|real person|team member|\bagent\b|connect me)"),
    ("negotiation", r"(discount|negotiat\w*|best price|final price|lower the price|reduce the price|bargain|offer|scheme|waive)"),
    ("legal", r"\b(legal|agreement|registration|rera|title|paperwork|stamp duty|encumbrance|sale deed|mutation|conversion|"
              r"approval|approved|noc|loan|bank|emi|tax|documents?|ownership|litigation)\b"),
    ("price", r"\b(price|prices|pricing|cost|costs|rate|rates|how much|kitna|daam|per (sq|katha|sft)|quote|charges?)\b"),
    ("availability", r"\b(available|availability|sold|inventory|units left|plots left|vacant|possession|status|ready to move|handover|"
                     r"under construction|completion)\b"),
    ("location", r"\b(where|location|address|located|situated|map|direction|directions|route|reach|distance|how far|nearby|near|"
                 r"landmark|landmarks|station|metro|airport|hospital|school|college|market|connectivity|highway)\b"),
    ("amenities", r"\b(amenit\w*|facilit\w*|features?|clubhouse|club|gym|pool|swimming|parking|security|garden|park|lift|elevator|"
                  r"generator|power|water|playground|temple|backup|infrastructure|electricity|road|roads|cctv)\b"),
    ("contact", r"\b(phone number|contact (number|details|info)|email id|email address|whatsapp number|office address|your number)\b"),
    ("visit", r"\b(visit|site visit|come and see|tour|show me|walkthrough|walk through)\b"),
    ("summary", r"\b(summary|summarise|summarize|recap|what do you have so far|what have i told you)\b"),
    ("thanks", r"^\s*(thanks|thank you|thx|ok thanks|okay thanks|great thanks)\W*$"),
    ("greeting", r"^\s*(hi|hello|hey|namaste|hii+|good (morning|afternoon|evening))\W*$"),
]
GENERIC_AMENITY = re.compile(r"\b(amenit\w*|facilit\w*|features?|infrastructure|what (do|does) .* (have|offer)|what('s| is) (there|available))\b")
AMENITY_TRIGGERS = re.compile(
    r"\b(clubhouse|club|gym|pool|swimming|parking|security|garden|park|lift|elevator|generator|power|water|playground|temple|"
    r"backup|electricity|road|roads|cctv)\b")
QUESTIONISH = re.compile(r"(\?|^\s*(what|when|where|which|who|whom|whose|why|how|is|are|do|does|did|can|could|will|would|should|kya|kitna|kab|kahan|kaun)\b)")


def detect_intents(text):
    s = text.lower()
    found = []
    for name, rx in INTENTS:
        if re.search(rx, s):
            found.append(name)
    return found


def faq_match(text, c):
    s = text.lower()
    hits = []
    for f in c.get("faq", []):
        if any(re.search(r"\b" + re.escape(k) + r"\b", s) for k in f["keys"]):
            hits.append(f)
    return hits


# ------------------------------------------------------------------ answers (config only)
def team_confirm(lead, text, what=None):
    q = text.strip()[:200]
    if q and q not in lead["open_questions"]:
        lead["open_questions"].append(q)
    base = f"I don't have a confirmed answer on {what} here, so a team member needs to confirm it." if what else \
        "I don't have a confirmed answer for that, so a team member needs to confirm it."
    return base + " I've noted your question for them."


def answer_price(lead, c, text):
    pr = c.get("pricing", {})
    inv = pr.get("inventory") or []
    if inv:
        pick = None
        t = _norm(text)
        for it in inv:
            if any(_norm(k) in t for k in it.get("match", []) + [it["label"]]):
                pick = it
        rows = [pick] if pick else inv
        lines = [f"{r['label']}: {r['price_text']}" + (f" ({r['area_text']})" if r.get("area_text") else "") for r in rows]
        return "Here is what I have configured:\n" + "\n".join(lines) + "\nFinal pricing and offers are confirmed by our team."
    note = pr.get("note") or "I don't have published pricing for this project."
    extra = ""
    if lead["budget_label"]:
        extra = f" I've noted your budget ({lead['budget_label']}) so the team can match options to it."
    return f"{note} A team member needs to share current pricing and availability.{extra}"


def answer_location(lead, c, text):
    loc = c["location"]
    if not loc.get("summary"):
        return team_confirm(lead, text, "the location")
    s = text.lower()
    marks = loc.get("landmarks", [])
    hit = [m for m in marks if any(k in s for k in m.get("keys", []) + [m["name"].lower()])]
    if hit:
        body = "; ".join(f"{m['name']}: {m['distance']}" for m in hit[:6])
        return f"{loc['summary']} From the website, nearby: {body}."
    if marks:
        body = "; ".join(f"{m['name']} ({m['distance']})" for m in marks[:5])
        return f"{loc['summary']} Nearby, per the website: {body}."
    return loc["summary"]


def answer_amenities(lead, c, text):
    am = c.get("amenities", [])
    if not am:
        return team_confirm(lead, text, "the infrastructure and amenities")
    s = text.lower()
    specific = [a for a in am if any(_norm(k) in _norm(s) for k in a.get("aliases", []) + [a["label"]])]
    if specific and not GENERIC_AMENITY.search(s):
        out = []
        for a in specific[:4]:
            out.append(a.get("detail") or f"Yes, {a['label']} is listed on the project website.")
        return " ".join(out)
    if AMENITY_TRIGGERS.search(s) and not GENERIC_AMENITY.search(s):
        return team_confirm(lead, text, "that")
    return "Listed on the project website: " + ", ".join(a["label"] for a in am) + ". Anything beyond this a team member confirms."


def answer_contact(lead, c):
    ct = c.get("contact", {})
    parts = []
    if ct.get("phone"):
        parts.append(f"phone {ct['phone']}")
    if ct.get("whatsapp"):
        parts.append(f"WhatsApp {ct['whatsapp']}")
    if ct.get("email"):
        parts.append(f"email {ct['email']}")
    if ct.get("address"):
        parts.append(f"address {ct['address']}")
    if not parts:
        return "I don't have contact details configured here. I can arrange for a team member to contact you, if you'd like."
    return "From the project website: " + "; ".join(parts) + "."


def answer_faq(hits):
    return " ".join(h["answer"] for h in hits[:2])


# ----------------------------------------------------------------------- scoring
def score_lead(lead):
    p = 0.0
    tl = lead["timeline"]
    p += {"asap": 3, "1_3": 2.5, "3_6": 1, "6_plus": 0}.get(tl, 0)
    p += 1 if lead["budget_label"] else 0
    p += 1 if lead["size_label"] else 0
    p += 0.5 if lead["location_pref"] else 0
    p += 0.5 if lead["features"] else 0
    p += 1 if lead["role"] == "decision_maker" else 0
    p += 2 if lead["consult_type"] == "visit" else 1.5 if lead["consult_type"] == "call" else 0
    p += 2 if lead["handoff_requested"] else 0
    return "Hot" if p >= 6 else "Warm" if p >= 3 else "Cold"


def known_unknown(lead, c):
    known, unknown = [], []
    ptype = lead["property_type"]
    if ptype:
        known.append(("Property type", TYPE_LABELS.get(ptype, ptype).capitalize()))
    elif len(c["property_types"]) == 1:
        known.append(("Property type", TYPE_LABELS[c["property_types"][0]].capitalize()))
    pairs = [
        ("purpose", "Purpose", lead["purpose"]), ("size", "Size", lead["size_label"]),
        ("location", "Location", lead["location_pref"]), ("budget", "Budget", lead["budget_label"]),
        ("timeline", "Timeline", lead["timeline_label"]),
        ("role", "Role", {"decision_maker": "Decision-maker", "helping": "Helping someone else", "researching": "Researching"}.get(lead["role"])),
    ]
    for step, label, val in pairs:
        if val:
            known.append((label, val))
        else:
            unknown.append(label)
    feats = list(lead["features"]) + ([lead["features_other"]] if lead["features_other"] else [])
    if feats:
        known.append(("Must-haves", ", ".join(feats)))
    else:
        unknown.append("Must-haves")
    if lead["consult_type"] == "visit":
        known.append(("Site visit", lead["visit_pref"] or "date to be agreed"))
    elif lead["consult_type"] == "call":
        known.append(("Next step", "Sales consultation call"))
    elif lead["consult_type"] == "none":
        known.append(("Next step", "No consultation for now"))
    else:
        unknown.append("Next step")
    if lead["contact_channel"] and lead["contact_channel"] != "none":
        ch = {o["id"]: o["label"] for o in CHANNEL_OPTIONS}[lead["contact_channel"]]
        known.append(("Contact", f"{ch}{', ' + lead['contact_time'] if lead['contact_time'] else ''}"
                                f"{' (follow-up allowed)' if lead['followup_consent'] else ' (follow-up not confirmed)' if lead['followup_consent'] is not None else ''}"))
    elif lead["contact_channel"] == "none":
        known.append(("Contact", "Only in this chat"))
    else:
        unknown.append("Contact preference")
    return known, unknown


def crm_summary(lead, c):
    known, unknown = known_unknown(lead, c)
    k = "; ".join(f"{a}: {b}" for a, b in known)
    u = ", ".join(unknown)
    ho = f" HANDOFF: {lead['handoff_reason']}." if lead["handoff_requested"] else ""
    oq = f" Open questions: {' | '.join(lead['open_questions'])}." if lead["open_questions"] else ""
    return f"{lead['name']} ({lead['phone']}) on {c['name']}. {k}. Not shared: {u or 'none'}.{ho}{oq} Score {lead['score']}."


def chat_summary(lead, c):
    known, unknown = known_unknown(lead, c)
    lines = ["Here's what I have so far:"]
    lines += [f"• {a}: {b}" for a, b in known]
    if unknown:
        lines.append("Not shared yet: " + ", ".join(unknown) + ".")
    return "\n".join(lines)


def progress(lead, c):
    done = 0
    for st in SCRIPT_STEPS:
        if st == "property_type":
            done += 1 if (lead["property_type"] or len(c["property_types"]) == 1) else 0
        elif st == "contact":
            done += 1 if (lead["contact_channel"] == "none" or (lead["contact_channel"] and lead["followup_consent"] is not None)) else 0
        elif is_answered(lead, st):
            done += 1
    return [done, len(SCRIPT_STEPS)]


# ---------------------------------------------------------------- applying values
def apply_purpose(lead, c, text=None, opt=None):
    if opt:
        lead["purpose"] = opt["label"]
    elif text:
        lead["purpose"] = text.strip()[:80]
    return f"Purpose: {lead['purpose']}"


def apply_size(lead, c, parsed=None, opt=None, raw=None):
    if opt:
        lead["size_label"], lead["size_unit"] = opt["label"], opt.get("unit")
        lead["size_min"], lead["size_max"] = opt.get("min"), opt.get("max")
    elif parsed:
        lead["size_label"], lead["size_unit"] = parsed["label"], parsed["unit"]
        lead["size_min"], lead["size_max"] = parsed["min"], parsed["max"]
    elif raw:
        lead["size_label"], lead["size_unit"], lead["size_min"], lead["size_max"] = raw.strip()[:80], None, None, None
    return f"Size: {lead['size_label']}"


def apply_budget(lead, b):
    lead["budget_label"] = b["label"]
    lead["budget_min_lakh"], lead["budget_max_lakh"], lead["budget_approx"] = b["min_lakh"], b["max_lakh"], b["approx"]
    if "budget" in lead["unknown_fields"]:
        lead["unknown_fields"].remove("budget")
    return f"Budget: {b['label']}"


def apply_timeline(lead, c, months):
    if months == "undecided":
        mark_unknown(lead, "timeline")
        return "Timeline: not decided yet"
    for o in timeline_options(c):
        if months <= o["max_months"]:
            lead["timeline"], lead["timeline_label"] = o["id"], o["label"]
            return f"Timeline: {o['label']}"
    return None


def timeline_from_option(lead, o):
    lead["timeline"], lead["timeline_label"] = o["id"], o["label"]
    return f"Timeline: {o['label']}"


# ------------------------------------------------------------------ main entry
def start(lead, c):
    """First bot turn for a new session."""
    if len(c["property_types"]) == 1:
        lead["property_type"] = c["property_types"][0]
    tline = f" ({c['tagline']})" if c.get("tagline") else ""
    greet = (f"Hi {first_name(lead)}! I'm the virtual assistant for {c['name']}{tline}. "
             f"I can answer questions about the project and help you arrange a visit. {c.get('disclaimer', '')}").strip()
    if lead["property_type"]:
        greet += f"\n\nI'll ask a few quick questions about the {TYPE_LABELS[lead['property_type']]} you want, and you can ask me anything along the way."
    return _finish(lead, c, [greet], events=[])


def _finish(lead, c, msgs, events, extra_chips=None):
    step = next_step(lead, c)
    lead["awaiting"] = step
    chips = []
    ctx = lead["ctx"]
    if step is None:
        if not ctx.get("complete_sent"):
            ctx["complete_sent"] = True
            events.append("qualification_complete")
            msgs.append(chat_summary(lead, c))
            msgs.append(_closing(lead, c))
        chips = [{"id": "q:human", "label": "👤 Talk to a team member"}, {"id": "edit", "label": "✏️ Change an answer"}]
        if c.get("amenities") or c["location"].get("summary"):
            chips.append({"id": "q:location", "label": "📍 Ask about the location"})
    else:
        q = prompt(step, lead, c)
        if q:
            msgs.append(q)
        chips = chips_for(step, lead, c)
    if extra_chips:
        chips = extra_chips + chips
    lead["score"] = score_lead(lead)
    if lead["handoff_requested"]:
        lead["stage"] = "Handoff requested"
    elif step is None:
        lead["stage"] = "Qualified"
    elif lead["stage"] == "New":
        lead["stage"] = "In conversation"
    lead["summary"] = crm_summary(lead, c)
    lead["updated_at"] = now_iso()
    return {"messages": [m for m in msgs if m], "chips": chips, "quick": quick_actions(c), "events": events,
            "progress": progress(lead, c), "step": step}


def view(lead, c):
    """Chips and progress for the current state, without sending any new message (used when a chat is resumed)."""
    step = next_step(lead, c)
    if step is None:
        chips = [{"id": "q:human", "label": "👤 Talk to a team member"}, {"id": "edit", "label": "✏️ Change an answer"}]
    else:
        chips = chips_for(step, lead, c)
    return {"chips": chips, "quick": quick_actions(c), "progress": progress(lead, c), "step": step}


def _closing(lead, c):
    fu = lead["followup_consent"]
    ch = {o["id"]: o["label"] for o in CHANNEL_OPTIONS}.get(lead["contact_channel"] or "", "")
    if lead["consult_type"] == "visit":
        pref = f" for {lead['visit_pref']}" if lead["visit_pref"] else ""
        notes = " ".join(x for x in [c.get("visit", {}).get("hours_note"), c.get("visit", {}).get("extras")] if x)
        base = f"Your site visit request{pref} is with our team. It is a request, not a confirmed booking yet, and a team member will confirm the slot with you."
        if notes:
            base += " " + notes
    elif lead["consult_type"] == "call":
        base = "Your request for a sales consultation is with our team."
    else:
        base = "Thanks for sharing all this."
    if fu is True:
        base += f" They'll reach out by {ch.lower()}" + (f" in the {lead['contact_time'].lower()}" if lead["contact_time"] else "") + "."
    elif fu is False or lead["contact_channel"] == "none":
        base += " We won't contact you outside this chat. You can reach the team yourself anytime, just ask me for the contact details."
    return base + " You can keep asking me questions, or ask for a team member whenever you like."


def handle(lead, c, text, chip_id=None):
    text = (text or "").strip()
    ctx = lead["ctx"]
    step = lead["awaiting"]
    msgs, events, acks = [], [], []
    extra_chips = None
    handled_answer = False  # an answer to the current question was consumed

    # ---------------------------------------------------------- chips
    if chip_id:
        r = _apply_chip(lead, c, chip_id, step, acks, msgs, events)
        if r == "handoff_consent":
            return _handoff_flow(lead, c, msgs, events)
        if r == "edit":
            return _edit_menu(lead, c, msgs, events)
        handled_answer = r is True
        acks.clear()  # a tapped option is already visible in the chat, no need to echo it
    else:
        # ------------------------------------------------------ free text
        low = text.lower()
        intents = detect_intents(text)
        if "human" in intents:
            return _handoff_flow(lead, c, msgs, events, reason="Visitor asked for a team member")
        fa = faq_match(text, c)

        # 1. the answer to the current question (typed)
        handled_answer = _typed_answer(lead, c, text, step, intents, acks, msgs)

        # 2. other facts mentioned in passing (skip what is known)
        _opportunistic(lead, c, text, step, acks, handled_answer)

        # 3. questions
        answered_q = False
        if "visit" in intents and lead["consult_type"] is None:
            lead["consult_type"] = "visit"
            acks.append("Site visit: requested")
            answered_q = True
        if fa:
            msgs.append(answer_faq(fa))
            answered_q = True
        else:
            for it in intents:
                if it == "price":
                    msgs.append(answer_price(lead, c, text)); answered_q = True
                elif it == "location" and not (step == "location" and handled_answer):
                    msgs.append(answer_location(lead, c, text)); answered_q = True
                elif it == "amenities" and not (step == "features" and handled_answer):
                    msgs.append(answer_amenities(lead, c, text)); answered_q = True
                elif it == "contact":
                    msgs.append(answer_contact(lead, c)); answered_q = True
                elif it in ("legal", "negotiation", "availability"):
                    what = {"legal": "legal, registration or loan details", "negotiation": "discounts and offers",
                            "availability": "current availability"}[it]
                    msgs.append(team_confirm(lead, text, what)); answered_q = True
                elif it == "summary":
                    msgs.append(chat_summary(lead, c)); answered_q = True
                elif it == "thanks":
                    msgs.append("You're welcome!"); answered_q = True
                elif it == "greeting":
                    answered_q = True
                if answered_q and it in ("price", "legal", "negotiation"):
                    break
        if not handled_answer and not answered_q and not acks:
            if QUESTIONISH.search(low) and len(text) > 3:
                msgs.append(team_confirm(lead, text))
                extra_chips = [{"id": "q:human", "label": "👤 Talk to a team member"}]
            elif step:
                ctx["misses"] = ctx.get("misses", 0) + 1
                msgs.append("Sorry, I didn't quite catch that. " + ("Please tap one of the options below, or rephrase." if ctx["misses"] < 3
                            else "Tap an option below, or choose “Talk to a team member” and someone will help."))
                if ctx["misses"] >= 3:
                    extra_chips = [{"id": "q:human", "label": "👤 Talk to a team member"}]
        else:
            ctx["misses"] = 0

    pre = []
    if ctx.pop("handoff_confirmed", None) is not None:
        yes = lead["followup_consent"]
        events.append("handoff_consent")
        pre.append("Thank you. A team member will contact you." if yes else
                   "Understood. I've told the team not to contact you outside this chat. You can reach them any time by asking me for the contact details.")
    if acks:
        pre.append("Got it: " + " · ".join(a for a in acks if a) + ".")
    if not pre and not msgs and lead["awaiting"] is None and next_step(lead, c) is None:
        msgs.append("Is there anything else I can help with? You can ask about the project, or talk to a team member.")
    if lead["handoff_requested"] and not ctx.get("stopped") and next_step(lead, c):
        stop = [{"id": "stop:done", "label": "That's all for now"}]
        extra_chips = (extra_chips or []) + stop
    return _finish(lead, c, pre + msgs, events, extra_chips)


# ------------------------------------------------------------------- typed answers
FILLER = re.compile(r"^\W*(hm+|hmm+|ok|okay|k|yes|yeah|yep|no|nope|hi+|hello|hey|fine|sure|thanks|thank you|oh|uh|um|huh|what|\?+|\.+)\W*$", re.I)


def _has_other_facts(text):
    """True when the message carries a size, budget or timeline, so it must not be stored as free text."""
    b = P.parse_budget(text)
    return bool(FILLER.match(text) or P.parse_size(text) or (b and "min_lakh" in b) or
                (P.parse_timeline(text) not in (None, "undecided") and re.search(r"\b(month|week|year|asap)", text.lower())))


def _typed_answer(lead, c, text, step, intents, acks, msgs):
    ctx = lead["ctx"]
    ctx_before = dict(ctx)
    if step is None:
        return False
    if step == "property_type":
        o = match_option(text, [t for t in TYPE_OPTIONS if t["id"] in c["property_types"]])
        if o:
            lead["property_type"] = o["id"]
            acks.append(f"Property type: {TYPE_LABELS[o['id']]}")
            return True
        other = match_option(text, [t for t in TYPE_OPTIONS if t["id"] not in c["property_types"]])
        if other:
            msgs.append(f"{c['name']} doesn't list {TYPE_LABELS[other['id']]}s that I know of, so a team member would need to confirm.")
        return False
    if step == "purpose":
        o = match_option(text, purposes(lead, c))
        if o:
            acks.append(apply_purpose(lead, c, opt=o)); return True
        if UNSURE_RE.search(text.lower()):
            mark_unknown(lead, "purpose"); return True
        if not intents and not QUESTIONISH.search(text.lower()) and 2 < len(text) <= 80 and not _has_other_facts(text):
            acks.append(apply_purpose(lead, c, text=text)); return True
        return False
    if step == "size":
        o = match_option(text, size_cfg(lead, c).get("options", []))
        p = P.parse_size(text)
        if p:
            acks.append(apply_size(lead, c, parsed=p)); return True
        if o:
            acks.append(apply_size(lead, c, opt=o)); return True
        if UNSURE_RE.search(text.lower()):
            mark_unknown(lead, "size"); return True
        return False
    if step == "location":
        o = match_option(text, c["location"].get("options", []))
        if UNSURE_RE.search(text.lower()):
            mark_unknown(lead, "location"); return True
        if o and not QUESTIONISH.search(text.lower()):
            lead["location_pref"] = o["label"]; acks.append(f"Location: {o['label']}"); return True
        loc_only = [i for i in intents if i != "location"]
        if not loc_only and not QUESTIONISH.search(text.lower()) and 2 < len(text) <= 80 and not _has_other_facts(text):
            lead["location_pref"] = text.strip()[:80]; acks.append(f"Location: {lead['location_pref']}"); return True
        return False
    if step == "budget":
        if ctx.get("budget_ambig"):
            m = re.search(r"\b(lakh|lac|lakhs|crore|cr|crores)\b", text.lower())
            if m:
                v = ctx.pop("budget_ambig")
                b = P.parse_budget(f"{v:g} {m.group(1)}")
                acks.append(apply_budget(lead, b)); return True
        b = P.parse_budget(text, awaiting=True)
        return _take_budget(lead, c, b, acks, msgs)
    if step == "timeline":
        m = P.parse_timeline(text)
        if m is None:
            o = match_option(text, timeline_options(c))
            if o:
                acks.append(timeline_from_option(lead, o)); return True
            return False
        a = apply_timeline(lead, c, m)
        if a:
            acks.append(a); return True
        return False
    if step == "role":
        r = P.parse_role(text)
        if r:
            lead["role"] = r
            acks.append("Role: " + {o["id"]: o["label"] for o in ROLE_OPTIONS}[r]); return True
        o = match_option(text, ROLE_OPTIONS)
        if o:
            lead["role"] = o["id"]; acks.append("Role: " + o["label"]); return True
        if UNSURE_RE.search(text.lower()):
            mark_unknown(lead, "role"); return True
        return False
    if step == "features":
        pool = c.get("amenities") or c.get("requirement_choices") or []
        low = text.lower()
        if QUESTIONISH.search(low):
            return False
        if re.search(r"\b(that'?s all|thats all|done|nothing|none|no more|that is all|nothing specific|nope)\b", low) and not match_option(text, pool):
            ctx["features_done"] = True; return True
        hit = [o for o in pool if any(_norm(k) in _norm(text) for k in o.get("aliases", []) + [o["label"]])]
        added = []
        for o in hit:
            if o["label"] not in lead["features"]:
                lead["features"].append(o["label"]); added.append(o["label"])
        if added:
            acks.append("Essential: " + ", ".join(added))
            return True
        if UNSURE_RE.search(low):
            ctx["features_done"] = True; mark_unknown(lead, "features"); return True
        if not intents and not QUESTIONISH.search(low) and 2 < len(text) <= 120 and not _has_other_facts(text):
            lead["features_other"] = ((lead["features_other"] + "; ") if lead["features_other"] else "") + text.strip()[:120]
            acks.append(f"Also needed: {text.strip()[:60]}"); return True
        return False
    if step == "consult":
        o = match_option(text, CONSULT_OPTIONS)
        if "visit" in intents and (not o or o["id"] != "none"):
            lead["consult_type"] = "visit"; acks.append("Site visit: requested"); return True
        if o:
            lead["consult_type"] = o["id"]
            acks.append({"visit": "Site visit: requested", "call": "Sales consultation: requested", "none": "No consultation for now"}[o["id"]])
            return True
        yn = P.parse_yes_no(text)
        if yn is False:
            lead["consult_type"] = "none"; return True
        return False
    if step == "visit_when":
        w = P.parse_when(text, today_ist())
        if UNSURE_RE.search(text.lower()):
            mark_unknown(lead, "visit_when"); return True
        if not w or ("visit" in intents and not w["parsed"]):
            return False
        if w["parsed"] and w["date"] and not w["time"]:
            ctx["visit_date"] = w["label"]; return True
        if w["parsed"] and w["time"] and not w["date"] and ctx.get("visit_date"):
            lead["visit_pref"] = f"{ctx.pop('visit_date')}, {w['time']}"
        else:
            lead["visit_pref"] = w["label"]
            ctx.pop("visit_date", None)
        acks.append(f"Visit preference: {lead['visit_pref']}")
        return True
    if step == "channel":
        o = match_option(text, CHANNEL_OPTIONS)
        if o:
            return _set_channel(lead, o["id"], acks)
        return False
    if step == "email":
        e = P.parse_email(text)
        if e:
            lead["email"] = e; acks.append(f"Email: {e}"); return True
        msgs.append("That doesn't look like an email address. Please type it again, like name@example.com.")
        return True  # consumed (we re-ask)
    if step == "contact_time":
        o = match_option(text, CONTACT_TIME_OPTIONS)
        if o:
            lead["contact_time"] = o["label"]; acks.append(f"Best time: {o['label']}"); return True
        return False
    if step == "permission":
        yn = P.parse_yes_no(text)
        if yn is None:
            return False
        _set_consent(lead, yn, acks)
        return True
    return False


def _take_budget(lead, c, b, acks, msgs):
    ctx = lead["ctx"]
    if not b:
        return False
    if b.get("unknown"):
        mark_unknown(lead, "budget"); return True
    if b.get("emi"):
        msgs.append("Thanks. That sounds like a monthly EMI figure. What is your total budget or price range? A rough number is fine, or you can skip it.")
        return True
    if b.get("ambiguous"):
        ctx["budget_ambig"] = b["ambiguous"]; return True
    a = apply_budget(lead, b)
    if b.get("assumed"):
        a += f" (I took that as {b['label']}. Tell me if that's not right.)"
    acks.append(a)
    return True


def _opportunistic(lead, c, text, step, acks, handled):
    """Pick up details volunteered out of order: '2 bhk under seventy lakhs, ready in 3 months'."""
    ctx = lead["ctx"]
    if step != "budget" and not ctx.get("budget_ambig"):
        b = P.parse_budget(text)
        if b and "min_lakh" in b:
            acks.append(apply_budget(lead, b))
    if step != "size":
        p = P.parse_size(text)
        if p and (p["unit"] in ("bhk", "katha", "sq ft", "acre", "bigha", "cottah", "sq m", "sq yd")):
            # only accept units that make sense for this project's property type
            ok = {"flat": {"bhk", "sq ft"}, "plot": {"katha", "sq ft", "cottah", "bigha", "sq m", "sq yd"},
                  "industrial": {"sq ft", "acre", "bigha", "sq m", "katha"}}.get(lead["property_type"] or c["property_types"][0], set())
            if p["unit"] in ok:
                acks.append(apply_size(lead, c, parsed=p))
    if step != "timeline" and lead["timeline"] is None and "timeline" not in lead["unknown_fields"]:
        m = P.parse_timeline(text)
        if m not in (None, "undecided") and re.search(r"\b(month|week|year|asap|immediate|urgent|soon|quarter)", text.lower()):
            a = apply_timeline(lead, c, m)
            if a:
                acks.append(a)
    if step != "purpose" and lead["purpose"] is None:
        o = match_option(text, purposes(lead, c))
        if o and o["id"] in ("investment", "live", "build") and len(text) > 6:
            acks.append(apply_purpose(lead, c, opt=o))
    if step != "location" and lead["location_pref"] is None and "location" not in lead["unknown_fields"]:
        o = match_option(text, c["location"].get("options", []))
        if o and o["id"] not in ("other", "this", "nearby") and not QUESTIONISH.search(text.lower()):
            lead["location_pref"] = o["label"]; acks.append(f"Location: {o['label']}")
    if step != "role" and lead["role"] is None:
        r = P.parse_role(text)
        if r and r != "researching":
            lead["role"] = r
            acks.append("Role: " + {o["id"]: o["label"] for o in ROLE_OPTIONS}[r])


def _set_channel(lead, cid, acks):
    lead["contact_channel"] = cid
    lab = {o["id"]: o["label"] for o in CHANNEL_OPTIONS}[cid]
    acks.append(f"Contact: {lab}")
    if cid == "none":
        lead["followup_consent"] = False
        lead["followup_consent_at"] = now_iso()
        lead["contact_time"] = None
    return True


def _set_consent(lead, yes, acks):
    lead["followup_consent"] = bool(yes)
    lead["followup_consent_at"] = now_iso()
    acks.append("Follow-up: allowed" if yes else "Follow-up: only in this chat")
    if not yes:
        lead["contact_channel"] = "none"
    if lead["ctx"].pop("handoff_pending", False):
        lead["ctx"]["handoff_confirmed"] = True


# --------------------------------------------------------------------------- chips
def _apply_chip(lead, c, chip_id, step, acks, msgs, events):
    ctx = lead["ctx"]
    kind, _, val = chip_id.partition(":")
    if chip_id == "ask_team" or chip_id == "q:human":
        return "handoff_consent"
    if kind == "q":
        if val == "location":
            msgs.append(answer_location(lead, c, ""))
        elif val == "amenities":
            msgs.append(answer_amenities(lead, c, "amenities"))
        elif val == "price":
            msgs.append(answer_price(lead, c, ""))
        return False
    if chip_id == "edit":
        msgs.append("Which answer would you like to change?")
        ctx["editing"] = True
        return "edit"
    if kind == "edit":
        return _edit(lead, c, val, msgs)
    if kind == "budget_unit":
        v = ctx.pop("budget_ambig", None)
        if v is not None:
            acks.append(apply_budget(lead, P.parse_budget(f"{v:g} {val}")))
        return True
    if kind == "visit_time":
        o = next((x for x in VISIT_TIMES if x["id"] == val), None)
        if o:
            d = ctx.pop("visit_date", "")
            lead["visit_pref"] = f"{d}, {o['label']}".strip(", ")
            acks.append(f"Visit preference: {lead['visit_pref']}")
        return True
    if kind == "visit_when":
        if val == "unsure":
            mark_unknown(lead, "visit_when"); return True
        if val.startswith("d:"):
            from datetime import date as _d
            d = _d.fromisoformat(val[2:])
            ctx["visit_date"] = d.strftime("%a %d %b")
        return True
    if kind == "stop":
        ctx["stopped"] = True
        return True
    if step is None or kind != step:
        return False
    if val == "unsure":
        if step == "features":
            ctx["features_done"] = True
        mark_unknown(lead, step)
        return True
    if step == "property_type":
        lead["property_type"] = val; acks.append(f"Property type: {TYPE_LABELS[val]}")
    elif step == "purpose":
        o = next(x for x in purposes(lead, c) if x["id"] == val); acks.append(apply_purpose(lead, c, opt=o))
    elif step == "size":
        o = next(x for x in size_cfg(lead, c).get("options", []) if x["id"] == val); acks.append(apply_size(lead, c, opt=o))
    elif step == "location":
        o = next(x for x in c["location"].get("options", []) if x["id"] == val)
        lead["location_pref"] = o["label"]; acks.append(f"Location: {o['label']}")
    elif step == "budget":
        b = next(x for x in c.get("budget_bands", []) if x["id"] == val)
        acks.append(apply_budget(lead, {"label": b["label"], "min_lakh": b["min_lakh"], "max_lakh": b["max_lakh"], "approx": False}))
    elif step == "timeline":
        o = next(x for x in timeline_options(c) if x["id"] == val); acks.append(timeline_from_option(lead, o))
    elif step == "role":
        lead["role"] = val; acks.append("Role: " + {o["id"]: o["label"] for o in ROLE_OPTIONS}[val])
    elif step == "features":
        if val == "done":
            ctx["features_done"] = True
            return True
        pool = c.get("amenities") or c.get("requirement_choices") or []
        o = next(x for x in pool if x["id"] == val)
        if o["label"] not in lead["features"]:
            lead["features"].append(o["label"])
        acks.append("Essential: " + o["label"])
        return False  # stay on this question so they can add more
    elif step == "consult":
        lead["consult_type"] = val
        acks.append({"visit": "Site visit: requested", "call": "Sales consultation: requested", "none": "No consultation for now"}[val])
    elif step == "channel":
        _set_channel(lead, val, acks)
    elif step == "contact_time":
        o = next(x for x in CONTACT_TIME_OPTIONS if x["id"] == val); lead["contact_time"] = o["label"]; acks.append(f"Best time: {o['label']}")
    elif step == "permission":
        _set_consent(lead, val == "yes", acks)
    return True


def _edit_menu(lead, c, msgs, events):
    labels = [("purpose", "Purpose"), ("size", "Size"), ("location", "Location"), ("budget", "Budget"),
              ("timeline", "Timeline"), ("role", "Role"), ("features", "Must-haves"), ("consult", "Next step"),
              ("contact", "Contact preference")]
    chips = [{"id": f"edit:{k}", "label": v} for k, v in labels]
    lead["awaiting"] = None
    return {"messages": ["Which answer would you like to change?"], "chips": chips, "quick": quick_actions(c),
            "events": events, "progress": progress(lead, c), "step": None}


def _edit(lead, c, val, msgs):
    lead["ctx"].pop("editing", None)
    lead["ctx"].pop("stopped", None)
    if val == "contact":
        for st in ("channel", "email", "contact_time", "permission"):
            clear_step(lead, st)
        lead["followup_consent_at"] = None
        lead["ctx"].pop("complete_sent", None)
        return True
    if val == "consult":
        clear_step(lead, "visit_when")
    if val in STEP_COLS or val == "features":
        clear_step(lead, val)
        lead["ctx"].pop("complete_sent", None)
    return True


# -------------------------------------------------------------------------- handoff
def _handoff_flow(lead, c, msgs, events, reason="Visitor asked for a team member"):
    ctx = lead["ctx"]
    if not lead["handoff_requested"]:
        lead["handoff_requested"] = True
        lead["handoff_reason"] = reason
        events.append("handoff_requested")
    first = []
    if lead["followup_consent"] is True:
        first.append("Of course. I've flagged this chat for a team member, with everything you've told me so far, and they'll contact you "
                     f"on {lead['phone']}.")
        return _finish(lead, c, first + msgs, events)
    if lead["followup_consent"] is False and lead["contact_channel"] == "none":
        first.append("Of course. I've flagged this chat for a team member. Since you asked us not to contact you outside this chat, "
                     "I'll mark that, and you can also reach the team directly. Ask me for the contact details if you'd like them.")
        return _finish(lead, c, first + msgs, events)
    first.append(f"Of course. I've flagged this chat for a team member, with everything you've told me so far. "
                 f"Is it OK for them to contact you on {lead['phone']}?")
    ctx["handoff_pending"] = True
    lead["awaiting"] = "permission"
    lead["summary"] = crm_summary(lead, c)
    lead["updated_at"] = now_iso()
    return {"messages": first + msgs,
            "chips": [chip("permission", "yes", "Yes, that's fine"), chip("permission", "no", "No, only in this chat")],
            "quick": quick_actions(c), "events": events, "progress": progress(lead, c), "step": "permission"}
